
@guest()
    <?php  $id = 'null'; ?>
@else
    <?php $id = \Illuminate\Support\Facades\Auth::user()->id; ?>
@endif
<div class="row">
    <div class="col-lg-12">
        <div class="card-body">
            <div class="title-product">
                <div class="text-product">
                    <div class="text-left">
                        Program bank bjb
                    </div>
                </div>
            </div>
            <div class="text-product-right mt-4">
                <a href="" class="btn btn-primary btn-xl"
                   style="padding: 7px 20px 7px 20px; border-radius: 2vh 0 2vh 0;">Lihat Semua</a>
            </div>
        </div>
    </div>
    <div class="brands-slider bg-transparent owl-carousel owl-theme images-center">
        <a href="#" onclick="Go('{{$id}}', '15')">
            <div class="">
                <img src="{{URL::to('images/dep/3.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 3</h5>
                <h5 class="text-center">Description Promo 3</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/1.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 1</h5>
                <h5 class="text-center">Description Promo 1</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/2.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 2</h5>
                <h5 class="text-center">Description Promo 2</h5>
            </div>
        </a>

        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/4.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 4</h5>
                <h5 class="text-center">Description Promo 4</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/5.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 5</h5>
                <h5 class="text-center">Description Promo 5</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/9.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 9</h5>
                <h5 class="text-center">Description Promo 9</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/6.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 6</h5>
                <h5 class="text-center">Description Promo 6</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/7.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 7</h5>
                <h5 class="text-center">Description Promo 7</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/8.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 8</h5>
                <h5 class="text-center">Description Promo 8</h5>
            </div>
        </a>

        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/10.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 10</h5>
                <h5 class="text-center">Description Promo 10</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/11.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Program 11</h5>
                <h5 class="text-center">Description Promo 11</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/all.png')}}" style="padding: 15%" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">View</h5>
                <h5 class="text-center">All</h5>
            </div>
        </a>

    </div>

    <div class="col-lg-12">
        <div class="card-body">
            <div class="title-product">
                <div class="text-product">
                    <div class="text-left">
                        Promo bank bjb
                    </div>
                </div>
            </div>
            <div class="text-product-right mt-4">
                <a href="" class="btn btn-primary btn-xl"
                   style="padding: 7px 20px 7px 20px; border-radius: 2vh 0 2vh 0;">Lihat Semua</a>
            </div>
        </div>
    </div>
    <div class="brands-slider bg-transparent owl-carousel owl-theme images-center">
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/1.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 1</h5>
                <h5 class="text-center">Description Promo 1</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/2.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 2</h5>
                <h5 class="text-center">Description Promo 2</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/3.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 3</h5>
                <h5 class="text-center">Description Promo 3</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/4.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 4</h5>
                <h5 class="text-center">Description Promo 4</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/5.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 5</h5>
                <h5 class="text-center">Description Promo 5</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/6.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 6</h5>
                <h5 class="text-center">Description Promo 6</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/7.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 7</h5>
                <h5 class="text-center">Description Promo 7</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/8.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 8</h5>
                <h5 class="text-center">Description Promo 8</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/9.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 9</h5>
                <h5 class="text-center">Description Promo 9</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/10.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 10</h5>
                <h5 class="text-center">Description Promo 10</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/11.png')}}" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">Promo 11</h5>
                <h5 class="text-center">Description Promo 11</h5>
            </div>
        </a>
        <a href="">
            <div class="">
                <img src="{{URL::to('images/dep/all.png')}}" style="padding: 15%" width="50" height="50" alt="brand">
                <h5 class="text-center mt-3">View</h5>
                <h5 class="text-center">All</h5>
            </div>
        </a>

    </div>



{{--    <div class="container">--}}
{{--        <div class="products-slider custom-products owl-carousel owl-theme nav-outer show-nav-hover nav-image-center"--}}
{{--             data-owl-options="{--}}
{{--    						'dots': false,--}}
{{--    						'nav': true--}}
{{--    					}">--}}
{{--            @foreach($news as $key => $data)--}}
{{--                <div class="card card-block card-stretch card-height blog blog-date">--}}
{{--                    <div class="card-body">--}}
{{--                        <div class="image-block position-relative">--}}
{{--                            <img src="{{URL::to('images/news/thumb/'.$data->thumb)}}" class="img-fluid rounded w-100"--}}
{{--                                 alt="blog-img">--}}
{{--                            <div class="blog-meta-date">--}}
{{--                                <div class="date">{{date('d', strtotime($data->created_at))}}</div>--}}
{{--                                <div class="month">{{date('M', strtotime($data->created_at))}}</div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="blog-description mt-3">--}}
{{--                            <div class="blog-meta d-flex align-items-center justify-content-between mb-2">--}}
{{--                                <div class="author">bank bjb</div>--}}
{{--                            </div>--}}
{{--                            <h5 class="mb-2">{{$data->title}}</h5>--}}
{{--                            <p>{!!$data->thumb_desc!!}</p>--}}
{{--                            <a href="#" tabindex="-1">Read More <i--}}
{{--                                    class="ri-arrow-right-s-line"></i></a>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            @endforeach--}}
{{--        </div><!-- End .featured-proucts -->--}}
{{--    </div>--}}

    <div style="margin-top: 50px; padding: 20px;">
        <div class="row">
            <div class="col-lg-12">
                <div class="card-body">
                    <div class="title-product">
                        <div class="text-product">
                            <div class="text-left">
                                Informasi Terkini bank bjb
                            </div>
                        </div>
                    </div>
                    <div class="text-product-right mt-4">
                        <a href="" class="btn btn-primary btn-xl"
                           style="padding: 7px 20px 7px 20px; border-radius: 2vh 0 2vh 0;">Lihat Semua</a>
                    </div>
                </div>
            </div>
            @foreach($news as $key => $data)
                @if($key % 2 == !0)
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="card card-block card-stretch card-height blog blog-date">
                            <div class="card-body">
                                <div class="blog-description mt-3">
                                    <h5 class="mb-2">{{$data->title}}</h5>
                                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                                        <div class="author">bank bjb</div>
                                    </div>
                                    <p>{!!$data->thumb_desc!!}</p>
                                    <a href="{{url('news/'.$data->news_slug)}}" tabindex="-1">Read More <i
                                            class="ri-arrow-right-s-line"></i></a>
                                </div>
                                <div class="image-block position-relative">
                                    <a href="{{url('news/'.$data->news_slug)}}">
                                    <img src="{{URL::to('images/news/thumb/'.$data->thumb)}}" class="img-fluid rounded w-100"
                                         alt="blog-img">
                                    <div class="blog-meta-date">
                                        <div class="date">{{date('d', strtotime($data->created_at))}}</div>
                                        <div class="month">{{date('M', strtotime($data->created_at))}}</div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="card card-block card-stretch card-height blog blog-date">
                            <div class="card-body">
                                <div class="image-block position-relative">
                                    <a href="{{url('news/'.$data->news_slug)}}">
                                    <img src="{{URL::to('images/news/thumb/'.$data->thumb)}}" class="img-fluid rounded w-100"
                                         alt="blog-img">
                                    <div class="blog-meta-date">
                                        <div class="date">{{date('d', strtotime($data->created_at))}}</div>
                                        <div class="month">{{date('M', strtotime($data->created_at))}}</div>
                                    </div>
                                    </a>
                                </div>
                                <div class="blog-description mt-3">
                                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                                        <div class="author">bank bjb</div>
                                    </div>
                                    <h5 class="mb-2">{{$data->title}}</h5>
                                    <p>{!!$data->thumb_desc!!}</p>
                                    <a href="{{url('news/'.$data->news_slug)}}" tabindex="-1">Read More <i
                                            class="ri-arrow-right-s-line"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
    </div>

</div>

    <script>
    function Go(id, v){
        $.get("{{url('api/get-url')}}/" +id+"/"+v, function (data) {
            data.url_origin
            window.open(data.url_origin);
        });


    }
</script>
