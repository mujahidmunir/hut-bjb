
<script src="{{URL::to('assets/js/backend-bundle.min.js')}}"></script>


<!-- slider JavaScript -->
<script src="{{URL::to('assets/js/slider.js')}}"></script>

<!-- app JavaScript -->
<script src="{{URL::to('assets/js/app.js')}}"></script>
<script src="{{URL::to('assets/js/imagesloaded.pkgd.min.js')}}"></script>

<script src="{{URL::to('assets/js/plugin.js')}}"></script>


@yield('js')
