<!doctype html>
<html lang="en">

<?php echo $__env->make('layouts.assets.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="dahboard-2  ">
<!-- loader Start -->
<div id="loading">
    <div id="loading-center">

    </div>
</div>
<!-- loader END -->
<!-- Wrapper Start -->
<div class="wrapper">
    <?php echo $__env->make('layouts.assets.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('slider'); ?>
    <div class="content-page c-payment-block">
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>
<!-- Wrapper End-->
<?php echo $__env->make('layouts.assets.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Backend Bundle JavaScript -->
<?php echo $__env->make('layouts.assets.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/hut-bjb/resources/views/master.blade.php ENDPATH**/ ?>