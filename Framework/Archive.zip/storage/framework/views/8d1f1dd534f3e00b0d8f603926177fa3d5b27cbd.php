<!-- BEGIN: Vendor CSS-->
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('admin/app-assets/vendors/css/vendors.min.css')); ?>">
<link rel="stylesheet" type="text/css"
      href="<?php echo e(URL::to('admin/app-assets/vendors/css/tables/datatable/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" type="text/css"
      href="<?php echo e(URL::to('admin/app-assets/vendors/css/tables/datatable/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" type="text/css"
      href="<?php echo e(URL::to('admin/app-assets/vendors/css/tables/datatable/buttons.bootstrap4.min.css')); ?>">
<link rel="stylesheet" type="text/css"
      href="<?php echo e(URL::to('admin/app-assets/vendors/css/tables/datatable/rowGroup.bootstrap4.min.css')); ?>">
<link rel="stylesheet" type="text/css"
      href="<?php echo e(URL::to('admin/app-assets/vendors/css/pickers/flatpickr/flatpickr.min.css')); ?>">
<!-- END: Vendor CSS-->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Hut-Bjb/resources/views/layouts/admin/assets/component/data-table/head.blade.php ENDPATH**/ ?>