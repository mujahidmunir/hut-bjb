
<script src="<?php echo e(URL::to('assets/js/backend-bundle.min.js')); ?>"></script>


<!-- slider JavaScript -->
<script src="<?php echo e(URL::to('assets/js/slider.js')); ?>"></script>

<!-- app JavaScript -->
<script src="<?php echo e(URL::to('assets/js/app.js')); ?>"></script>
<script src="<?php echo e(URL::to('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>

<script src="<?php echo e(URL::to('assets/js/plugin.js')); ?>"></script>


<?php echo $__env->yieldContent('js'); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/hut-bjb/resources/views/layouts/assets/js.blade.php ENDPATH**/ ?>