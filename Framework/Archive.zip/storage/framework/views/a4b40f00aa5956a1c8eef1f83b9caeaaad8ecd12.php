<div class="dashboard2-header-style">
    <div class="iq-top-navbar analytic">
            <div class="iq-navbar-custom d-flex align-items-center justify-content-between">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu text-primary"></i>
                    <a href="index-2.html" class="header-logo">
                        <img src="<?php echo e(URL::to('images/logo/logo-bjb-utama.png')); ?>" class="img-fluid rounded-normal" alt="logo">
                    </a>
                </div>

            </div>
    </div>
    <?php echo $__env->make('layouts.assets.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Hut-Bjb/resources/views/layouts/assets/header.blade.php ENDPATH**/ ?>