<?php $__env->startSection('slider'); ?>
    <?php echo $__env->make('layouts.assets.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-page-1">
        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog">
                    <div class="card-body">
                        <div class="image-block">
                            <img src="<?php echo e(URL::to('assets/images/blog/07.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                        </div>
                        <div class="blog-description mt-3">
                            <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                                <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                                </div>
                                <div class="hit">0 Hits</div>
                            </div>
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                            <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog">
                    <div class="card-body">
                        <div class="image-block">
                            <img src="<?php echo e(URL::to('assets/images/blog/08.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                        </div>
                        <div class="blog-description mt-3">
                            <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                                <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                                </div>
                                <div class="hit">0 Hits</div>
                            </div>
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                            <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog">
                    <div class="card-body">
                        <div class="image-block">
                            <img src="<?php echo e(URL::to('assets/images/blog/09.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                        </div>
                        <div class="blog-description mt-3">
                            <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                                <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                                </div>
                                <div class="hit">0 Hits</div>
                            </div>
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                            <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog blog-date">
                    <div class="card-body">
                        <div class="image-block position-relative">
                            <img src="<?php echo e(URL::to('assets/images/blog/10.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                            <div class="blog-meta-date">
                                <div class="date">05</div>
                                <div class="month">March</div>
                            </div>
                        </div>
                        <div class="blog-description mt-3">
                            <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                                <div class="author"><i class="ri-user-fill pr-2"></i>By: Admin</div>
                                <div class="hit"><i class="ri-heart-fill pr-2"></i>0 Hits</div>
                            </div>
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog blog-date">
                    <div class="card-body">
                        <div class="image-block position-relative">
                            <img src="<?php echo e(URL::to('assets/images/blog/11.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                            <div class="blog-meta-date">
                                <div class="date">06</div>
                                <div class="month">Apr</div>
                            </div>
                        </div>
                        <div class="blog-description mt-3">
                            <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                                <div class="author"><i class="ri-user-fill pr-2"></i>By: Admin</div>
                                <div class="hit"><i class="ri-heart-fill pr-2"></i>75 Hits</div>
                            </div>
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog blog-date">
                    <div class="card-body">
                        <div class="image-block position-relative">
                            <img src="<?php echo e(URL::to('assets/images/blog/12.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                            <div class="blog-meta-date">
                                <div class="date">10</div>
                                <div class="month">May</div>
                            </div>
                        </div>
                        <div class="blog-description mt-3">
                            <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                                <div class="author"><i class="ri-user-fill pr-2"></i>By: Admin</div>
                                <div class="hit"><i class="ri-heart-fill pr-2"></i>86 Hits</div>
                            </div>
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog blog-comments">
                    <div class="card-body">
                        <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                            <div class="author"><i class="ri-user-fill pr-2"></i>By: Admin</div>
                            <div class="hit"><i class="ri-heart-fill pr-2"></i>28 Hits</div>
                        </div>
                        <div class="image-block position-relative">
                            <img src="<?php echo e(URL::to('assets/images/blog/13.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                            <div class="blog-meta-date">
                                <div class="date">01</div>
                                <div class="month">Jan</div>
                            </div>
                        </div>
                        <div class="blog-description mt-3">
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p class="mb-0">In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity." </p>
                            <a href="#" tabindex="-1" class="pl-2">Read More <i class="ri-arrow-right-s-line"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog blog-comments">
                    <div class="card-body">
                        <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                            <div class="author"><i class="ri-user-fill pr-2"></i>By: Admin</div>
                            <div class="hit"><i class="ri-heart-fill pr-2"></i>65 Hits</div>
                        </div>
                        <div class="image-block position-relative">
                            <img src="<?php echo e(URL::to('assets/images/blog/14.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                            <div class="blog-meta-date">
                                <div class="date">22</div>
                                <div class="month">Feb</div>
                            </div>
                        </div>
                        <div class="blog-description mt-3">
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p class="mb-0">In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity." </p>
                            <a href="#" tabindex="-1" class="pl-2">Read More <i class="ri-arrow-right-s-line"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-6 col-lg-4">
                <div class="card card-block card-stretch card-height blog blog-comments">
                    <div class="card-body">
                        <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                            <div class="author"><i class="ri-user-fill pr-2"></i>By: Admin</div>
                            <div class="hit"><i class="ri-heart-fill pr-2"></i>96 Hits</div>
                        </div>
                        <div class="image-block position-relative">
                            <img src="<?php echo e(URL::to('assets/images/blog/15.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                            <div class="blog-meta-date">
                                <div class="date">18</div>
                                <div class="month">March</div>
                            </div>
                        </div>
                        <div class="blog-description mt-3">
                            <h5 class="mb-2">Containing coronavirus spread comes</h5>
                            <p class="mb-0">In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity." </p>
                            <a href="#" tabindex="-1" class="pl-2">Read More <i class="ri-arrow-right-s-line"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Hut-Bjb/resources/views/pages/events/events.blade.php ENDPATH**/ ?>