
<div class="row">
    <div class="col-lg-6">
        <div class="card card-block card-stretch card-height blog blog-left">
            <div class="card-body position-relative">
                <div class="image-block">
                    <div class="embed-responsive embed-responsive-1by1">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/QAIHRtCecCg" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="blog-description">
                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                        <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                        </div>
                    </div>
                    <h5 class="mb-2">Containing coronavirus spread comes</h5>
                    <p class="text-blog-description">In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>

                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card card-block card-stretch card-height blog">
            <div class="card-body">
                <ul class="list-inline m-0 p-0">
                    <li class="mb-2">
                        <div class="blog-half d-flex align-items-center">
                            <div class="blog-meta bg-primary">
                                <div class="date">16</div>
                                <div class="month">April</div>
                            </div>
                            <div class="blog-description">
                                <h5 class="mb-2">V-Ride 2021 Series 1</h5>
                                <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                            </div>
                        </div>
                    </li>
                    <li class="mb-2">
                        <div class="blog-half d-flex align-items-center">
                            <div class="blog-meta bg-success">
                                <div class="date">20</div>
                                <div class="month">April</div>
                            </div>
                            <div class="blog-description">
                                <h5 class="mb-2">V-Ride 2021 Series 2</h5>
                                <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                            </div>
                        </div>
                    </li>
                    <li class="mb-2">
                        <div class="blog-half d-flex align-items-center">
                            <div class="blog-meta bg-warning">
                                <div class="date">29</div>
                                <div class="month">April</div>
                            </div>
                            <div class="blog-description">
                                <h5 class="mb-2">V-Ride 2021 Series 2</h5>
                                <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                            </div>
                        </div>
                    </li>

                    <li>
                        <div class="blog-half d-flex align-items-center">
                            <div class="blog-meta bg-danger">
                                <div class="date">16</div>
                                <div class="month">Sept</div>
                            </div>
                            <div class="blog-description">
                                <h5 class="mb-2">Containing coronavirus spread comes</h5>
                                <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p>
                            </div>
                        </div>
                    </li>
                    <li class="text-right"><a href="" class="btn btn-warning">Lihat Semua</a> </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-4">
        <div class="card card-block card-stretch card-height blog">
            <div class="card-body">
                <div class="image-block">
                    <img src="<?php echo e(URL::to('assets/images/blog/01.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                </div>
                <div class="blog-description mt-3">
                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                        <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                        </div>
                        <div class="hit">0 Hits</div>
                    </div>
                    <h5 class="mb-2">Containing coronavirus spread comes</h5>
                    <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p> <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-4">
        <div class="card card-block card-stretch card-height blog">
            <div class="card-body">
                <div class="image-block">
                    <img src="<?php echo e(URL::to('assets/images/blog/02.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                </div>
                <div class="blog-description mt-3">
                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                        <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                        </div>
                        <div class="hit">0 Hits</div>
                    </div>
                    <h5 class="mb-2">Containing coronavirus spread comes</h5>
                    <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p> <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-4">
        <div class="card card-block card-stretch card-height blog">
            <div class="card-body">
                <div class="image-block">
                    <img src="<?php echo e(URL::to('assets/images/blog/03.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
                </div>
                <div class="blog-description mt-3">
                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                        <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                        </div>
                        <div class="hit">0 Hits</div>
                    </div>
                    <h5 class="mb-2">Containing coronavirus spread comes</h5>
                    <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p> <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-3">
        <div class="card card-block card-stretch card-height blog">
            <div class="image-block">
                <img src="<?php echo e(URL::to('assets/images/blog/04.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
            </div>
            <div class="card-body">
                <div class="blog-description">
                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                        <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                        </div>
                        <div class="hit">0 Hits</div>
                    </div>
                    <h5 class="mb-2">Containing coronavirus spread comes</h5>
                    <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p> <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-3">
        <div class="card card-block card-stretch card-height blog">
            <div class="card-body">
                <div class="blog-description">
                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                        <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                        </div>
                        <div class="hit">0 Hits</div>
                    </div>
                    <h5 class="mb-2">Containing coronavirus spread comes</h5>
                    <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p> <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                </div>
            </div>
            <div class="image-block">
                <img src="<?php echo e(URL::to('assets/images/blog/05.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-3">
        <div class="card card-block card-stretch card-height blog">
            <div class="image-block">
                <img src="<?php echo e(URL::to('assets/images/blog/06.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
            </div>
            <div class="card-body">
                <div class="blog-description">
                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                        <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                        </div>
                        <div class="hit">0 Hits</div>
                    </div>
                    <h5 class="mb-2">Containing coronavirus spread comes</h5>
                    <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p> <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-6 col-lg-3">
        <div class="card card-block card-stretch card-height blog">
            <div class="card-body">
                <div class="blog-description">
                    <div class="blog-meta d-flex align-items-center justify-content-between mb-2">
                        <div class="date"><a href="#" tabindex="-1">March 21, 2020</a>
                        </div>
                        <div class="hit">0 Hits</div>
                    </div>
                    <h5 class="mb-2">Containing coronavirus spread comes</h5>
                    <p>In the blogpost, the IMF experts observed, "Success in containing the virus comes at the price of slowing economic activity."</p> <a href="#" tabindex="-1">Read More <i class="ri-arrow-right-s-line"></i></a>
                </div>
            </div>
            <div class="image-block">
                <img src="<?php echo e(URL::to('assets/images/blog/07.jpg')); ?>" class="img-fluid rounded w-100" alt="blog-img">
            </div>
        </div>
    </div>
</div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/hut-bjb/resources/views/layouts/assets/blog.blade.php ENDPATH**/ ?>