<div class="bg-analytic-horizontal">
    <div class="">
        <div class="white-bg-menu">
            <div class="iq-menu-horizontal">
                <nav class="iq-sidebar-menu text-center">

                    <div class="iq-sidebar-logo d-flex align-items-center justify-content-between">
                        <a href="index-2.html" class="header-logo">
                            <img src="<?php echo e(URL::to('images/logo/logo-bjb.png')); ?>" class="img-fluid rounded-normal" alt="logo">
                        </a>
                        <div class="iq-menu-bt-sidebar">
                            <i class="fa fa-close wrapper-menu"></i>
                        </div>
                    </div>
                    <ul id="iq-sidebar-toggle" class="iq-menu d-flex mn-center">
                        <li class="<?php echo e('/' == request()->path() ? 'active-menu' : ''); ?>">
                            <a href="<?php echo e(url('/')); ?>" aria-expanded="false" class="font-size-20 align-items-center "><i class="fa fa-home"></i>Home</a>
                        </li>
                        <li class="<?php echo e('news' == request()->path() ? 'active-menu' : ''); ?>">
                            <a href="<?php echo e(url('news')); ?>" aria-expanded="false" class="font-size-20 ">
                                <i class="fa fa-newspaper-o iq-arrow-left"></i><span>Informasi</span>
                            </a>
                        </li>
                        <li class="<?php echo e('product' == request()->path() ? 'active-menu' : ''); ?>">
                            <a href="<?php echo e(url('products')); ?>" aria-expanded="false" class="font-size-20 ">
                                <i class="fa fa-newspaper-o iq-arrow-left"></i><span>Product</span>
                            </a>
                        </li>
                        <li class="<?php echo e('product' == request()->path() ? 'active-menu' : ''); ?>">
                            <a href="<?php echo e(url('products')); ?>" aria-expanded="false" class="font-size-20 ">
                                <i class="fa fa-newspaper-o iq-arrow-left"></i><span>bjb Point</span>
                            </a>
                        </li>


                            <?php if(auth()->guard()->guest()): ?>
                                <li class="">
                                    <a href="<?php echo e(url('login')); ?>" aria-expanded="false" class="font-size-20 ">
                                        <i class="fa fa-sign-in iq-arrow-left"></i><span>Login</span>
                                    </a>
                                </li>

                            <?php else: ?>
                            <li class="">
                                <a href="#UserAccount" class="collapsed" data-toggle="collapse" aria-expanded="false" class="font-size-20 ">
                                    <i class="fa fa-user iq-arrow-left"></i><span><?php echo e(Auth::user()->name); ?></span>
                                    <i class="fa fa-arrow-circle-right iq-arrow-right arrow-active"></i>
                                    <i class="fa fa-arrow-circle-down iq-arrow-right arrow-hover"></i>
                                </a>
                                <ul id="UserAccount" class="iq-submenu sub-scrll collapse"
                                    data-parent="#iq-sidebar-toggle">
                                    <?php if(Auth::user()->hasRole('admin')): ?>
                                    <li class="">
                                        <a href="<?php echo e(url('/')); ?>">
                                            <i class="fa fa-fa fa-user-circle-o"></i><span>My Account</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <li class="">
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </li>


                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>

                </nav>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Hut-Bjb/resources/views/layouts/assets/menu.blade.php ENDPATH**/ ?>