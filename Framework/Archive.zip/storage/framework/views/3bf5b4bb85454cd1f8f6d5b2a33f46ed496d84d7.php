<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::to('images/logo/logo-bjb.png')); ?>" />
    <title><?php echo e((Request::segment(1))); ?>

        <?php
        if (Request::segment(2) ==  true){
            $text = Request::segment(2);
            $title = str_replace('-', ' ', $text);
            echo ' '.'-'.' '.$title;
        }
        ?>
    </title>
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/css/backend.min0ff5.css?v=1.0.2')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(URL::to('assets/vendor/remixicon/fonts/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/vendor/@icon/dripicons/dripicons.css')); ?>">


</head>
<?php echo $__env->yieldContent('head'); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Hut-Bjb/resources/views/layouts/assets/head.blade.php ENDPATH**/ ?>