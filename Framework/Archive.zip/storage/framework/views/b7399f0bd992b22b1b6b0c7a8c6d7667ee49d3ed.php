<?php $__env->startSection('slider'); ?>
    <?php echo $__env->make('layouts.assets.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-block card-stretch card-height blog blog-detail">
                    <div class="card-header">
                        <h3><?php echo e($data->title); ?></h3>
                    </div>
                    <div class="card-body">

                        <div class="image-block">
                            <img src="<?php echo e(URL::to('images/news/origin', $data->thumb)); ?>" class="img-fluid rounded w-100"
                                 alt="blog-img">
                        </div>
                        <div class="blog-description mt-3">
                            <div class="blog-meta d-flex align-items-center mb-3">
                                <div class="float-left">
                                    <div class="date mr-4"><i
                                            class="ri-calendar-2-fill pr-2"></i><?php echo e(date('d M Y', strtotime($data->updated_at))); ?>

                                    </div>
                                </div>
                                <div class="float-right">
                                    <div class="author mr-4 d-none d-lg-flex d-sm-flex d-xl-flex"><i
                                            class="ri-user-fill pr-2"></i>By: Admin
                                    </div>
                                </div>

                            </div>
                            <h4 class="mb-2"><?php echo e($data->title); ?></h4>
                            <p>
                                <?php echo $data->description; ?>

                            </p>
                            <div class="embed-responsive embed-responsive-4by3">
                                <iframe class="embed-responsive-item"
                                        src="https://www.youtube.com/embed/<?php echo e($data->video_url); ?>"
                                        allowfullscreen></iframe>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Hut-Bjb/resources/views/pages/news/detail-new.blade.php ENDPATH**/ ?>