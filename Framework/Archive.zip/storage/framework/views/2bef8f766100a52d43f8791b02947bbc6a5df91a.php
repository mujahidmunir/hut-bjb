<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('assets/css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('slider'); ?>
    <?php if($agent->isPhone()): ?>
        <?php echo $__env->make('layouts.assets.slider-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('layouts.assets.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.assets.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(URL::to('assets/js/style.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Hut-Bjb/resources/views/index.blade.php ENDPATH**/ ?>