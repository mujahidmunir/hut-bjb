<?php $__env->startSection('content'); ?>
    <section class="bs-validation">
        <div class="msg mb-2"></div>
        <div class="row">
            <!-- Bootstrap Validation -->
            <div class="col-md-12 col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Buat Informasi Baru</h4>
                    </div>
                    <div class="card-body">
                        <form id="addNews" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="select-country1">Category</label>
                                <select class="select2 form-control" name="cat_id" id="category" required>
                                    <option value="">Select Category</option>
                                    <option value="addCategory">Tambah Category</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="basic-addon-name">Judul</label>
                                <input type="text" name="title" id="title" class="form-control" required/>
                            </div>
                            <div class="form-group">
                                <label for="select-country1">Content</label>
                                <textarea id="redactor" class="description" name="description"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" name="img" id="file" class="form-control">
                            </div>
                            <div class="card">
                                <div class="card-header bg-light border">
                                    <h5>Media</h5>
                                </div>
                                <div class="card-body border">
                                    <div class="row">
                                        <div class="col-2 mt-2">
                                            <div class="form-group">
                                                <label class="ml-50">Add</label>
                                                <div class="custom-control custom-control-primary custom-switch mt-50 ml-50">
                                                    <input type="checkbox" name="media"  class="agree custom-control-input form-control" id="customSwitch3" />
                                                    <label class="custom-control-label" for="customSwitch3"></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-10 mt-2">
                                            <div class="form-group">
                                                <label class="form-label" for="basic-addon-name">URL Video / ID Youtube</label>
                                                <input type="text" disabled name="video_url" id="url_video" class="form-control"/>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <div class="col-lg-6 col-md-12 mb-1 mb-lg-0">
                                    <button type="reset" class="btn btn-lg btn-gradient-danger btn-block round">Reset</button>
                                </div>
                                <div class="col-lg-6 col-md-12">
                                    <button type="submit" class="btn btn-lg btn-gradient-success btn-block round">Simpan</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('admin/app-assets/redactor/redactor.min.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('admin/assets/css/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(URL::to('admin/app-assets/redactor/redactor.min.js')); ?>"></script>
    <script src="<?php echo e(URL::to('admin/app-assets/redactor/_plugins/alignment/alignment.min.js')); ?>"></script>

    <script type="text/javascript">
        $R('#redactor', {
            minHeight: '300px',
            toolbarFixedTopOffset: 60,//, komana teu katulis, aya comment jd weuh komaan td siap. teu ngarti js wkwk oke
            plugins: ['alignment']
        });
    </script>
    <script>
        $(document).ready(function () {
            $.get("<?php echo e(url('api/cat')); ?>", function (data) {
                data.map(function (v) {
                    $('#category').append('<option value="'+v.id+'">'+v.cat_name+'</option>');
                });
            });
        });

        $('#category').on('change', function () {
            if(this.value == 'addCategory'){
                $('#addCat').modal('show');
            }
        })

        $('#createCat').on('submit', function (event) {
            event.preventDefault();
            $.ajax({
                data: $('#createCat').serialize(),
                url: "<?php echo e(URL::to('/api/cat')); ?>",
                method: "post",

                success: function (data) {
                    $('#createCat')[0].reset();
                    $('#addCat').modal('hide');
                    $('#category').html('<option value="">Select Category</option>\n' +
                                        '<option value="addCategory">Tambah Category</option>');
                    $('.msg').html('<div class="alert alert-success alert-dismissible fade show" role="alert">\n' +
                        '              <div class="alert-body">\n' +
                        '                Category '+data.cat_name+' Berhasil ditambahkan \n' +
                        '              </div>\n' +
                        '              <button type="button" class="close" data-dismiss="alert" aria-label="Close">\n' +
                        '                <span aria-hidden="true">×</span>\n' +
                        '              </button>\n' +
                        '            </div>\n');

                    $.get("<?php echo e(url('api/cat')); ?>", function (data) {
                        data.map(function (v) {
                            $('#category').append('<option value="'+v.id+'">'+v.cat_name+'</option>');
                        });
                    });

                }
            });
        });
        //create Post
        $('#addNews').on('submit', function (event) {
            event.preventDefault();
            $.ajax({
                url:"<?php echo e(url('api/create/news')); ?>",
                method:"POST",
                data: new FormData(this),
                contentType: false,
                cache:false,
                processData: false,
                dataType:"json",

                success: function (data) {
                    $('#title').prop('');
                    $('.msg').html('<div class="alert alert-success alert-dismissible fade show" role="alert">\n' +
                        '              <div class="alert-body">\n' +
                        '              '+data+'' +
                        '              </div>\n' +
                        '              <button type="button" class="close" data-dismiss="alert" aria-label="Close">\n' +
                        '                <span aria-hidden="true">×</span>\n' +
                        '              </button>\n' +
                        '            </div>\n');
                }
            });
        });
    </script>
    <script>
        $(".agree").click(function(){
            if($(this).prop("checked") == true){
                $('#url_video').prop("disabled", false);
                $('#url_video').prop("required", true);


            }
            else if($(this).prop("checked") == false){
                $('#url_video').prop("disabled", true);
                $('#url_video').prop("required", false);
            }
        });
    </script>


<?php $__env->stopSection(); ?>


<div class="modal modal-slide-in fade" id="addCat">
    <div class="modal-dialog sidebar-sm">
        <form class="add-new-record modal-content pt-0" method="post" id="createCat">
            <?php echo csrf_field(); ?>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
            <div class="modal-header mb-1">
                <h5 class="modal-title" id="exampleModalLabel">New Record</h5>
            </div>
            <div class="modal-body flex-grow-1">
                <div class="form-group">
                    <label class="form-label" for="basic-icon-default-fullname">Full Name</label>
                    <input type="text" class="form-control" name="cat_name"  />
                </div>
                <button type="submit" class="btn btn-primary data-submit mr-1">Submit</button>
                <button type="reset" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
            </div>
        </form>
    </div>
</div>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/hut-bjb/resources/views/admin/news/create.blade.php ENDPATH**/ ?>