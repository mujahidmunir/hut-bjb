<div class="row">
    <div class="banner">
            <img src="<?php echo e(URL::to('images/banner/banner.png')); ?>" class="d-block w-100" alt="#">
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/hut-bjb/resources/views/layouts/assets/banner.blade.php ENDPATH**/ ?>